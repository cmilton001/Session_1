INSERT into new_view values(8, 'Stan', 3000, 7);
INSERT into new_view values(9, 'Lyra', 700, 9);
SELECT * from new_view ;